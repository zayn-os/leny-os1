
// 🛑 DEPRECATED: This logic has moved to src/services/oracle/injector/index.ts
// Please ensure you are importing from the new modular structure.
export const processInjection = () => {
    throw new Error("This function has moved to src/services/oracle/injector/index.ts");
};
