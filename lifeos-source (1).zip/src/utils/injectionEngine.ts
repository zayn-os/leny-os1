
// 🛑 DEPRECATED: This logic has moved to src/services/oracle/injector.ts
// Please update your imports to use the new location.
export const processInjection = () => {
    throw new Error("This function has moved to src/services/oracle/injector.ts");
};
